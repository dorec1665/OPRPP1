package hr.fer.oprpp1.hw02.prob1;

public enum LexerState {

	/**
	 * Početno i obično stanje Lexera.
	 */
	BASIC,
	
	
	/**
	 * Prošireno stanje Lexera.
	 */
	EXTENDED;
}
