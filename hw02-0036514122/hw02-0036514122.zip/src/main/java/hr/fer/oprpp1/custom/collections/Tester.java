package hr.fer.oprpp1.custom.collections;

public interface Tester {
	
	boolean test(Object obj);

}
