package hr.fer.oprpp1.custom.scripting.elems;

/**
 * Nadklasa svim konretnim Element razredima koji ga nasljeđuju.
 * @author dario
 *
 */
public class Element {
	
	public String asText() {
		return "";
	}

}
