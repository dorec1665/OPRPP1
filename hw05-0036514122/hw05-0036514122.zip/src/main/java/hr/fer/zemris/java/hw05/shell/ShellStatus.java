package hr.fer.zemris.java.hw05.shell;


/**
 * Status MyShell programa.
 * @author dario
 *
 */
public enum ShellStatus {
	
	/**
	 * Nastavi rad.
	 */
	CONTINUE,
	
	
	/**
	 * Prekini rad.
	 */
	TERMINATE;
}
