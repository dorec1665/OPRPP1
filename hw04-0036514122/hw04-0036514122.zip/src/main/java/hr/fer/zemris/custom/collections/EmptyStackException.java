package hr.fer.zemris.custom.collections;

public class EmptyStackException extends RuntimeException{
	
	public EmptyStackException(String message) {
		super(message);
	}
	
	public EmptyStackException() {
		
	}
	

}
