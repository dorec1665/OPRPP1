package hr.fer.zemris.custom.collections;

public interface Tester<T> {
	
	boolean test(T obj);

}
