package hr.fer.zemris.custom.collections;

public interface Processor<T> {
	
	public void process(T object);

}
