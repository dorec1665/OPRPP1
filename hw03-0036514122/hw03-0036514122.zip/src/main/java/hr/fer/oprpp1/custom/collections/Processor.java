package hr.fer.oprpp1.custom.collections;

public interface Processor<T> {
	
	public void process(T object);

}
